package com.fisgateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class PGatewaycloudApplication {


	//http://localhost:8765/ADMINSERVICE/admin/movie
	//http://localhost:8765/CUSTOMERSERVICE/customer/detail

	//http://localhost:8765/adminservice/admin/movie
	//http://localhost:8765/customerservice/customer/detail

	public static void main(String[] args) {
		SpringApplication.run(PGatewaycloudApplication.class, args);
	}

}
