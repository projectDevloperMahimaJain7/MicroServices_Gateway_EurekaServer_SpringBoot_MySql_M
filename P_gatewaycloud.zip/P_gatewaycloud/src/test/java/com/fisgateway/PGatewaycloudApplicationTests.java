package com.fisgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PGatewaycloudApplicationTests {

	@Test
	void contextLoads() {
	}

}
