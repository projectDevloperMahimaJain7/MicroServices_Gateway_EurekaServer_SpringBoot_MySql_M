package com.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.admin.entity.Admin;
import com.admin.service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {
//http://localhost:7001/admin/movie
	@Autowired
	private AdminService adminService;
	@GetMapping("/welcome")
	public String home()
	{
		return "hello";
	}
	@GetMapping("/movie")
	public List<Admin> getAllDetails()
	{
		return this.adminService.getAllMovie();
	}
	
	@PostMapping("/movie")
	public Admin addMovie(@RequestBody Admin a)
	{
		return this.adminService.addAdmin(a);
		
	}
	@PutMapping("/movie/{mid}")
	public Admin updatingMovie(@RequestBody Admin a,@PathVariable("mid")int mid )

	{
		return this.adminService.updateMovie(a,mid);
		
	}
	@DeleteMapping("/movie/{mid}")
	public void deletMovir(@PathVariable("mid")int mid)
	{
		this.adminService.deleteMovie(mid);
	}
	//http://localhost:7001/admin/search/narrative
	@GetMapping("/search/{mtype}")
	public List<Admin> searchByMtype(@PathVariable("mtype")String mtype) {
		// TODO Auto-generated method stub
		return this.adminService.searchByMtype(mtype);
	}
}
