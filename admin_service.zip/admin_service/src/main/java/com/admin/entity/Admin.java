package com.admin.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Admin {

	@Id
	private int mid;
	private String mname;
	private int year;
	private String mlang;
	private int rating;
	private int dmin;
	private String mtype;
	private String mcategory;
	private String mdir;
	private String mactor1;
	private String mactor2;
	private int mrental;
	public Admin(int mid, String mname, int year, String mlang, int rating, int dmin, String mtype, String mcategory,
			String mdir, String mactor1, String mactor2, int mrental) {
		super();
		this.mid = mid;
		this.mname = mname;
		this.year = year;
		this.mlang = mlang;
		this.rating = rating;
		this.dmin = dmin;
		this.mtype = mtype;
		this.mcategory = mcategory;
		this.mdir = mdir;
		this.mactor1 = mactor1;
		this.mactor2 = mactor2;
		this.mrental = mrental;
	}
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getMlang() {
		return mlang;
	}
	public void setMlang(String mlang) {
		this.mlang = mlang;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public int getDmin() {
		return dmin;
	}
	public void setDmin(int dmin) {
		this.dmin = dmin;
	}
	public String getMtype() {
		return mtype;
	}
	public void setMtype(String mtype) {
		this.mtype = mtype;
	}
	public String getMcategory() {
		return mcategory;
	}
	public void setMcategory(String mcategory) {
		this.mcategory = mcategory;
	}
	public String getMdir() {
		return mdir;
	}
	public void setMdir(String mdir) {
		this.mdir = mdir;
	}
	public String getMactor1() {
		return mactor1;
	}
	public void setMactor1(String mactor1) {
		this.mactor1 = mactor1;
	}
	public String getMactor2() {
		return mactor2;
	}
	public void setMactor2(String mactor2) {
		this.mactor2 = mactor2;
	}
	public int getMrental() {
		return mrental;
	}
	public void setMrental(int mrental) {
		this.mrental = mrental;
	}
	@Override
	public String toString() {
		return "Admin [mid=" + mid + ", mname=" + mname + ", year=" + year + ", mlang=" + mlang + ", rating=" + rating
				+ ", dmin=" + dmin + ", mtype=" + mtype + ", mcategory=" + mcategory + ", mdir=" + mdir + ", mactor1="
				+ mactor1 + ", mactor2=" + mactor2 + ", mrental=" + mrental + "]";
	}
	
}
