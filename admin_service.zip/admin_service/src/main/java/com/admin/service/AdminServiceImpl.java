package com.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.admin.dao.AdminDao;
import com.admin.entity.Admin;


@Service
public class AdminServiceImpl implements AdminService {

	
	@Autowired
	private AdminDao adminDao;
	@Override
	public Admin addAdmin(Admin a) {
		// TODO Auto-generated method stub
		return this.adminDao.save(a);
	}
	@Override
	public List<Admin> getAllMovie() {
		// TODO Auto-generated method stub
		return this.adminDao.findAll();
	}
	@Override
	public Admin updateMovie(Admin a, int id) {
		// TODO Auto-generated method stub
		a.setMid(id);
		return this.adminDao.save(a);
	}
	@Override
	public void deleteMovie(int id) {
		// TODO Auto-generated method stub
	this.adminDao.deleteById(id);
	}
	@Override
	public List<Admin> searchByMtype(String mtype) {
		// TODO Auto-generated method stub
		return this.adminDao.findByMtype(mtype);
	}
	
	

}
