package com.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.entity.AdminDto;
import com.user.entity.Customer;
import com.user.service.CustomerService;



@RestController
@RequestMapping("customer")
public class CustomerController {

	@Autowired
	private CustomerService custService;
	@GetMapping("/welcome")
	public String home()
	{
		return "hello";
	}
	@GetMapping("/detail")
	public List<Customer> getAllDetails()
	{
		return this.custService.getAllCustomer();
	}
	
	@PostMapping("/detail")
	public Customer addUser(@RequestBody Customer a)
	{
		return this.custService.addCustomer(a);
		
	}
	@PutMapping("/detail/{cid}")
	public Customer updatingMovie(@RequestBody Customer a,@PathVariable("mid")int mid )

	{
		return this.custService.updateCustomer(a, mid);
		
	}
	@DeleteMapping("/movie/{cid}")
	public void deletMovir(@PathVariable("cid")int cid)
	{
		this.custService.deleteCustomer(cid);
	}
	//http://localhost:7002/customer/search/admin/movie/narrative
	@GetMapping("/search/admin/movie/{mtype}")
	public List<AdminDto> searchAdminMovieByMtype(@PathVariable("mtype")String mtype)
	{
		return this.custService.findAdminMovie(mtype);
	}
	
	
}
