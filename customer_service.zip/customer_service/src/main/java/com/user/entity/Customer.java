package com.user.entity;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Customer {
@Id
private int cid;
private String cname;
private int cmobile;
private String address;
private String cdreg;
private int cage;

private String mtype;

public Customer(int cid, String cname, int cmobile, String address, String cdreg, int cage, String mtype) {
	super();
	this.cid = cid;
	this.cname = cname;
	this.cmobile = cmobile;
	this.address = address;
	this.cdreg = cdreg;
	this.cage = cage;
	this.mtype = mtype;
}

public Customer() {
	super();
	// TODO Auto-generated constructor stub
}

public int getCid() {
	return cid;
}

public void setCid(int cid) {
	this.cid = cid;
}

public String getCname() {
	return cname;
}

public void setCname(String cname) {
	this.cname = cname;
}

public int getCmobile() {
	return cmobile;
}

public void setCmobile(int cmobile) {
	this.cmobile = cmobile;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public String getCdreg() {
	return cdreg;
}

public void setCdreg(String cdreg) {
	this.cdreg = cdreg;
}

public int getCage() {
	return cage;
}

public void setCage(int cage) {
	this.cage = cage;
}

public String getMtype() {
	return mtype;
}

public void setMtype(String mtype) {
	this.mtype = mtype;
}

@Override
public String toString() {
	return "Customer [cid=" + cid + ", cname=" + cname + ", cmobile=" + cmobile + ", address=" + address + ", cdreg="
			+ cdreg + ", cage=" + cage + ", mtype=" + mtype + "]";
}


}
