package com.user.service;

import java.util.List;

import com.user.entity.AdminDto;
import com.user.entity.Customer;

public interface CustomerService {
	
		public Customer addCustomer(Customer a);
		public List<Customer> getAllCustomer();
		public Customer updateCustomer(Customer a, int id);
		public void deleteCustomer(int id);
		public List<AdminDto> findAdminMovie(String mtype);
}

	
