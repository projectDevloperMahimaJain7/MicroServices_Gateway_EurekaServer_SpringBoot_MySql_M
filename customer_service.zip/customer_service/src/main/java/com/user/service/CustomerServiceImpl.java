package com.user.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.user.dao.CustomerDao;
import com.user.entity.AdminDto;
import com.user.entity.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private FeignProxy proxy;
	@Autowired
	private CustomerDao custDao;
	
	@Override
	public Customer addCustomer(Customer a) {
		// TODO Auto-generated method stub
		return this.custDao.save(a);
	}
	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return this.custDao.findAll();
	}
	@Override
	public Customer updateCustomer(Customer a, int id) {
		// TODO Auto-generated method stub
	a.setCid(id);
		return this.custDao.save(a);
	}
	@Override
	public void deleteCustomer(int id) {
		// TODO Auto-generated method stub
	this.custDao.deleteById(id);
	}
	
	@Override
	public List<AdminDto> findAdminMovie(String mtype) {
		// TODO Auto-generated method stub
		return proxy.searchByMtype(mtype);
	}
}
